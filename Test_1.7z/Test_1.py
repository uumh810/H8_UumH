# -*- coding: utf-8 -*-
"""
Created on Sat Jun  4 09:31:14 2022

@author: 048115
"""

print(123123/5)



print(10)
print(type(10))

print(4.2)
print(type(4.2))
print(4.)
print(.2)
print(.4e7)
print(4.2e-4)

print("uum")
print(type("uum"))

n= 300
print(n)




a=10
t=20
L=a*t/2
print (L)

a=b=c=300
print(a,b,c)

var=23.5
print(var)

var = "now i'm a string"
print(var)

name= "uum"
age = 19
has_laptops = True
print (name,age,has_laptops)

a = ['foo', 'bar', 'baz', 'qux', 'quux', 'corge']

print(a)

a[2] = 10
a[-1] = 20

print(a)

a = ['foo', 'bar', 'baz', 'qux', 'quux', 'corge']

print(a[1:4])

a[1:4] = [1.1, 2.2, 3.3, 4.4, 5.5]

print(a)

t = ('foo', 'bar', 'baz', 'qux', 'quux', 'corge')

print(t)

print(t[0])

print(t[-1])

(s1, s2, s3, s4) = ('foo', 'bar', 'baz', 'qux')

s1


MLB_team = {
    'Colorado': 'Rockies',
    'Boston': 'Red Sox',
    'Minnesota': 'Twins',
    'Milwaukee': 'Brewers',
    'Seattle': 'Mariners'
}

print(MLB_team['Minnesota'])
print(MLB_team['Colorado'])


MLB_team['Kansas City'] = 'Royals'
MLB_team

person = {}
type(person)

person['fname'] = 'Hack'
person['lname'] = 'PTP'
person['age'] = 51
person['spouse'] = 'Edna'
person['children'] = ['Ralph', 'Betty', 'Joey']
person['pets'] = {'dog': 'Fido', 'cat': 'Sox'}


